function yout = zbiornik1(a1,c1,c,w,x1,u)
    yout = (u-c1*(x1.^a1))/(c*w);
end
